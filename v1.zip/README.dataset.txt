# Дефектовка зефира > 2025-05-11 5:20pm
https://universe.roboflow.com/datascince3/-wp7mz

Provided by a Roboflow user
License: CC BY 4.0

Формирование датасета для обучения модели бинарной классификации и определения поврежденного/нормального зефира