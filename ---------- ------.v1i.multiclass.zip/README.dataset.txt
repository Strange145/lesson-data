# Дефектовка зефира > 2025-05-11 5:08pm
https://universe.roboflow.com/datascince3/-wp7mz

Provided by a Roboflow user
License: CC BY 4.0

